# -*- coding: utf-8 -*-
import sys
import uuid
import requests
import base64
import hashlib
import time
import re
requests.packages.urllib3.disable_warnings()
import json
#reload(sys)
#sys.setdefaultencoding('utf-8')

YOUDAO_URL = 'https://openapi.youdao.com/ocrapi'
APP_KEY = '01d087147135aaa7'
APP_SECRET = 'qFe7xbOmUddjqj35eMLSUjtzxeTTsr1p'


def truncate(q):
    q = q.decode('utf-8')
    if q is None:
        return None
    size = len(q)
    return q if size <= 20 else q[0:10] + str(size) + q[size - 10:size]


def encrypt(signStr):
    hash_algorithm = hashlib.sha256()
    hash_algorithm.update(signStr.encode('utf-8'))
    return hash_algorithm.hexdigest()


def do_request(data):
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    return requests.post(YOUDAO_URL, data=data, headers=headers, verify=False)


def connect():
    a1 = 'hw063'
    a2 = a1 + '.jpg'
    f = open(a2, 'rb')  # 二进制方式打开图文件
    q = base64.b64encode(f.read())  # 读取文件内容，转换为base64编码
    f.close()

    data = {}
    data['detectType'] = '10012'
    data['imageType'] = '1'
    data['langType'] = 'zh-en'
    data['img'] = q
    data['docType'] = 'json'
    data['signType'] = 'v3'
    curtime = str(int(time.time()))
    data['curtime'] = curtime
    salt = str(uuid.uuid1())
    signStr = APP_KEY + truncate(q) + salt + curtime + APP_SECRET
    sign = encrypt(signStr)
    data['appKey'] = APP_KEY
    data['salt'] = salt
    data['sign'] = sign

    response = do_request(data)
    a = response.content.decode('utf-8')
    aa=[i.start() for i in re.finditer('text', a)]
    bb = []
    for i in aa:
        b = ''
        while True:
            if a[i+7] != '' and a[i+7] != '"':
                b = b + a[i+7]
            if a[i+7] == '"':
                bb.append(b)
                break
            else:
                i = i + 1
    while '' in bb:
        bb.remove('')
    c1 = a1 + '.txt'
    with open(c1,'w') as f:
        for i in bb:
            f.writelines(i+'\n')
        f.close()
    return bb


def ocr():
    bb = connect()
    return bb
if __name__ == '__main__':
    bb = connect()
